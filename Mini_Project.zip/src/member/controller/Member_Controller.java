package member.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import company.domain.CompanyDTO;
import member.domain.MemberDTO;
import member.model.MemberDAO;
import member.model.MemberDAO_imple;

public class Member_Controller {

	public void mem_login(Scanner sc) {
	
		 
		 MemberDAO mdao = new MemberDAO_imple();
		 boolean isLogin = false; 
	      System.out.println("\n >>> --- 로그인 --- <<<");
	      
	      System.out.print("▷ 아이디 : ");
	      String userid = sc.nextLine();
	      System.out.print("▷ 비밀번호 : ");
	      String passwd = sc.nextLine();
	      
	      // mdao.login(userid, passwd);   가능하지만 spring 은 놉! => map 활용하기
	      Map<String, String> paraMap = new HashMap<>();      // key : string / values : string
	      paraMap.put("pk_user_id", userid);
	      paraMap.put("pass_wd", passwd);
	      
	      
	      MemberDTO member = mdao.login(paraMap);
	      
	      
	      
	      if(!(member.getPK_USER_ID()==null)) {
	    	  System.out.println(member.getUSER_NAME()+"님이 로그인 하셨습니다");
	    	  isLogin = true;
	    	  
	    	  
	      }
	      else {
	    	  System.out.println("[경고] 아이디 혹은 비밀번호가 일치하지 않습니다.");
	      }
	/////////////////////////////////////////////////////////////////
	    String s_choice = ""; 
	    do {  
		if(isLogin == true) {
	    	  System.out.println("---------------------------------------구직자 메뉴 [" + member.getUSER_NAME() +"님 로그인중]-----------------------------------\r\n"
	    	  		+ "        1.구인회사 검색    2.모집공고 검색      3.개인정보 조회     4.이력서 조회      5.로그아웃\r\n"
	    	  		+ "------------------------------------------------------------------------------------------------------------\r\n"
	    	  		+ "");
	    	  
	    	  System.out.print("▷ 메뉴번호 선택 : ");
              
	    	  s_choice = sc.nextLine();
              
              switch (s_choice) {
              case "1":   // 구인회사 검색
                search_com(member,sc);
                
            	  
            	  
                  break;
               case "2": // 모집공고검색
                  
            	  
            	   
            	   break;
               case "3":   // 개인정보조회
               	
               	
           
               	break;
                
               case "4":	// 이력서 조회
               
               	
               	break;
               	
               case "5":	// 로그아웃
                   System.out.println(">>> 로그아웃 되었습니다. <<<\n");
                   break;
                  
               default:
               	System.out.println(">> 메뉴에 없는 번호입니다. 다시 선택하세요 !! <<");
                  break;
               }   // end of switch (s_Choice)--------------------
            }   // end of if(isLogin == true)----------------------------
         
		
	} while(!"5".equals(s_choice));   // return 프로그램 종료일 때만 나갈 수 있게 하기
}


	
	private void search_com(MemberDTO member, Scanner sc) {
	

	System.out.println("-------------------구인회사 검색 [" + member.getUSER_NAME()  + "님 로그인중]-------------"
			+ "  1. 기업명 검색    2. 매출액 검색    3. 업종검색    4. 이전메뉴로 "
			+ "--------------------------------------------------------------------------\r\n"
			);
	
	System.out.print("▶ 메뉴번호 선택 :");
	 
	 String s_choice = sc.nextLine();
     
     switch (s_choice) {
     case "1":   // 기업명 검색 
      search_comname(member, sc);
   	  
   	  
         break;
      case "2": // 모집공고검색
         
   	  
   	   
   	   break;
      case "3":   // 개인정보조회
      	
      	
  
      	break;
       
      case "4":	// 이력서 조회
      
      	
      	break;
	}
	}


	
	
	
	
	
	
	
	
	
////////////////////////////////////////

	private void search_comname(MemberDTO member, Scanner sc) {
		System.out.println("-------------------구인회사 검색 [" + member.getUSER_NAME()  + "님 로그인중]-------------"
				+ "  1. 기업명 검색    2. 매출액 검색    3. 업종검색    4. 이전메뉴로"
				+ "--------------------------------------------------------------------------\r\n"
				);
		
	System.out.print("▶ 메뉴번호 선택 :  ");
	String menuno = sc.nextLine();
	
	System.out.print("▷ 검색어를 입력하세요 :");
	String searchn = sc.nextLine(); 
	
	Map<String, String> paraMap = new HashMap<>();
	paraMap.put("menuno", menuno);
	paraMap.put("searchn", searchn);
	
	CompanyDTO cmdto = cmdto.search_comname(paraMap);
	
	if(cmdto != null) {
		
	}

	}
		
	
	}

  
              
	      
	     

	      

	   



