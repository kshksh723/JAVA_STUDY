package company.model;

public interface CompanyDAO {

}
